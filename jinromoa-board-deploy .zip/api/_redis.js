// Redis 연결 공용 모듈 (Vercel Redis / REDIS_URL 방식)
import { createClient } from "redis";

let client = null;

export async function getRedis() {
  const url = process.env.REDIS_URL;
  if (!url) throw new Error("REDIS_URL 환경변수가 없습니다");
  if (client && client.isOpen) return client;
  client = createClient({ url, socket: { reconnectStrategy: (n) => Math.min(n * 100, 2000) } });
  client.on("error", () => {});
  await client.connect();
  return client;
}
