// 보관된 강사 서류 파일을 내려주는 API
import { getRedis } from "./_redis.js";

export default async function handler(req, res) {
  const id = (req.query && req.query.id) || "";
  if (!id) return res.status(400).send("id 없음");
  try {
    const r = await getRedis();
    const raw = await r.get("jm:file:" + id);
    if (!raw) return res.status(404).send("파일을 찾을 수 없습니다");
    const f = JSON.parse(raw);
    const buf = Buffer.from(f.data, "base64");
    res.setHeader("Content-Type", f.type || "application/octet-stream");
    res.setHeader(
      "Content-Disposition",
      "inline; filename*=UTF-8''" + encodeURIComponent(f.name || "file")
    );
    res.setHeader("Cache-Control", "private, max-age=3600");
    return res.status(200).send(buf);
  } catch (e) {
    return res.status(500).send("오류: " + String(e.message || e));
  }
}
