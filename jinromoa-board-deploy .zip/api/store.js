// 진로모아 운영보드 - 데이터 저장 API
import { getRedis } from "./_redis.js";

const PIN = process.env.APP_PIN || "";

export default async function handler(req, res) {
  if (req.method !== "POST") return res.status(405).json({ error: "POST only" });
  if (PIN && req.headers["x-pin"] !== PIN) return res.status(401).json({ error: "unauthorized" });

  const body = typeof req.body === "string" ? JSON.parse(req.body || "{}") : req.body || {};
  const op = body.op;

  try {
    const r = await getRedis();

    if (op === "load") {
      const [cases, staff, center] = await Promise.all([
        r.hVals("jm:cases"),
        r.hVals("jm:staff"),
        r.get("jm:center"),
      ]);
      const parse = (arr) =>
        (arr || [])
          .map((x) => { try { return JSON.parse(x); } catch (e) { return null; } })
          .filter(Boolean);
      return res.status(200).json({
        cases: parse(cases),
        staff: parse(staff),
        center: center ? JSON.parse(center) : null,
      });
    }

    if (op === "save") {
      const d = body.data || {};
      if (body.kind === "center") {
        await r.set("jm:center", JSON.stringify(d));
        return res.status(200).json({ ok: true });
      }
      if (!d.id) return res.status(400).json({ error: "id 없음" });
      await r.hSet(body.kind === "staff" ? "jm:staff" : "jm:cases", d.id, JSON.stringify(d));
      return res.status(200).json({ ok: true });
    }

    if (op === "delete") {
      await r.hDel(body.kind === "staff" ? "jm:staff" : "jm:cases", String(body.id));
      return res.status(200).json({ ok: true });
    }

    if (op === "csLink") {
      if (!/^[a-z0-9]{12,40}$/i.test(String(body.token || ""))) return res.status(400).json({ error: "token 오류" });
      await r.set("jm:cs:" + body.token, String(body.caseId));
      return res.status(200).json({ ok: true });
    }

    if (op === "fileSave") {
      const id = "f" + Date.now().toString(36) + Math.random().toString(36).slice(2, 7);
      await r.set(
        "jm:file:" + id,
        JSON.stringify({ name: body.name, type: body.type, data: body.data })
      );
      return res.status(200).json({ id });
    }

    if (op === "fileDelete") {
      await r.del("jm:file:" + body.id);
      return res.status(200).json({ ok: true });
    }

    return res.status(400).json({ error: "알 수 없는 요청" });
  } catch (e) {
    return res.status(500).json({ error: String(e.message || e) });
  }
}
