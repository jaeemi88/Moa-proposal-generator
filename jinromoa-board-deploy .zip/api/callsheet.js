// 강사용 콜시트 공개 링크 API (암호 없이 해당 강의 1건만 조회·응답)
import { getRedis } from "./_redis.js";

const DEFAULT_NOTE =
  "강의 종료 후 사진 2장, 서명부, 한 줄 소감을 보내주세요.\n" +
  "일정 변동이 있으면 최소 3일 전까지 연락 부탁드립니다.\n" +
  "강의 시작 30분 전 도착을 권장합니다.";

async function findCase(r, t) {
  if (!/^[a-z0-9]{12,40}$/i.test(t)) return null;
  const id = await r.get("jm:cs:" + t);
  if (!id) return null;
  const raw = await r.hGet("jm:cases", id);
  if (!raw) return null;
  const c = JSON.parse(raw);
  if (c.csToken !== t) return null; // 강사 변경 등으로 폐기된 링크
  return c;
}

export default async function handler(req, res) {
  try {
    const r = await getRedis();

    if (req.method === "GET") {
      const t = String((req.query && req.query.t) || "");
      const c = await findCase(r, t);
      if (!c) return res.status(404).json({ error: "만료되었거나 없는 링크입니다" });

      const center = JSON.parse((await r.get("jm:center")) || "{}");
      const hours = +c.hours || 0;
      const pay = (+c.payRate || 0) * hours;
      const wh = Math.round(pay * 0.033);
      const travel = +c.travel || 0;

      res.setHeader("Cache-Control", "no-store");
      return res.status(200).json({
        org: c.org || "", dept: c.dept || "", subject: c.subject || "", target: c.target || "",
        headcount: c.headcount || "", date: c.date || "", time: c.time || "", hours,
        place: c.place || "", roomType: c.roomType || "", screen: c.screen || "", pc: c.pc || "",
        mic: c.mic || "", net: c.net || "", roomNote: c.roomNote || "",
        meal: c.meal || "", mealPay: c.mealPay || "", mealNote: c.mealNote || "",
        mgr: c.mgr || "", phone: c.phone || "", instructor: c.instructor || "",
        distKm: c.distKm || "",
        pay, net: pay - wh, travel, total: pay - wh + travel,
        callnote: c.callnote || (center.callnote !== undefined ? center.callnote : DEFAULT_NOTE),
        centerName: center.name || "진로모아커리어센터",
        centerTel: center.tel || "010-6540-1524",
        answer: c.callAnswer || "", answerMemo: c.callMemo || "",
      });
    }

    if (req.method === "POST") {
      const body = typeof req.body === "string" ? JSON.parse(req.body || "{}") : req.body || {};
      const t = String(body.t || "");
      const answer = body.answer === "accept" ? "accept" : body.answer === "decline" ? "decline" : "";
      if (!answer) return res.status(400).json({ error: "응답 값이 없습니다" });

      const c = await findCase(r, t);
      if (!c) return res.status(404).json({ error: "만료되었거나 없는 링크입니다" });

      c.callAnswer = answer;
      c.callMemo = String(body.memo || "").slice(0, 500);
      c.callAnsweredAt = Date.now();
      if (answer === "accept" && c.status === "확정") c.status = "배정";

      await r.hSet("jm:cases", c.id, JSON.stringify(c));
      return res.status(200).json({ ok: true, answer });
    }

    return res.status(405).json({ error: "지원하지 않는 요청" });
  } catch (e) {
    return res.status(500).json({ error: String(e.message || e) });
  }
}
