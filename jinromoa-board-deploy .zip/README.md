# 진로모아 운영보드 — 배포 안내

## 준비물
- GitHub 계정
- Vercel 계정 (기존에 쓰시던 것)

이미 만들어두신 Vercel Redis를 그대로 사용합니다.
데이터 키가 `jm:` 으로 시작해 기존 면접스킬 데이터와 섞이지 않습니다.

---

## 1단계 · GitHub에 코드 올리기 (5분)

1. https://github.com 접속 → 오른쪽 위 **+** → **New repository**
2. 입력값
   - Repository name: `jinromoa-board`
   - **Private** 선택
   - 나머지는 그대로 두고 **Create repository**
3. 다음 화면에서 **uploading an existing file** 링크 클릭
4. 받으신 압축파일을 풀어서 나온 **모든 파일과 폴더**를 끌어다 놓습니다
   - `api` 폴더, `public` 폴더, `package.json`, `README.md`
5. 아래 **Commit changes** 클릭

---

## 2단계 · Vercel에 배포하기 (5분)

1. https://vercel.com 접속 → **Continue with GitHub** 로 로그인
2. **Add New** → **Project**
3. 방금 만든 `jinromoa-board` 옆 **Import** 클릭
4. **Environment Variables** 항목을 펼쳐 값 하나만 넣습니다

   | Name | Value |
   |---|---|
   | `APP_PIN` | 직접 정하는 접속 암호 (예: `jinromoa2026`) |

5. **Deploy** 클릭 → 1~2분 기다립니다
6. 완료되면 주소가 나옵니다 (예: `jinromoa-board.vercel.app`)

---

## 3단계 · 기존 Redis 연결하기 (2분) — 꼭 해야 합니다

1. 배포된 프로젝트 화면에서 **Storage** 탭 클릭
2. 목록에 기존에 쓰시던 **Redis** 가 보입니다 → **Connect** 클릭
   (또는 Redis를 먼저 열고 **Connect Project** 에서 `jinromoa-board` 선택)
3. 연결하면 `REDIS_URL` 이 자동으로 들어갑니다
4. **Deployments** 탭 → 맨 위 배포의 **⋯** → **Redeploy** 클릭

> 이 단계를 건너뛰면 앱을 열었을 때 저장이 되지 않습니다.

---

## 4단계 · 아이폰 홈 화면에 올리기 (2분)

1. **Safari**에서 3단계 주소 접속
2. 접속 암호(`APP_PIN`에 넣은 값) 입력
3. 아래 **공유 버튼** → **홈 화면에 추가**
4. 나무 로고 아이콘과 `진로모아` 이름 확인 후 **추가**

이제 아이콘을 누르면 바로 실행됩니다. 전화 걸기, 문자, 인쇄 모두 정상 작동합니다.

---

## 기존 데이터 옮기기

1. 지금 쓰시던 앱에서 **백업 파일 받기**
2. 새 주소의 앱에서 **백업 불러오기** → 그 파일 선택

---

## 알아두실 점

- **접속 암호**는 강사들과 공유할 때 알려주는 값입니다. 바꾸려면 Vercel → Settings → Environment Variables 에서 수정 후 재배포하세요.
- 강사 서류 파일은 **3MB 이하**만 올라갑니다. 사진은 촬영 후 그대로 올려도 대부분 통과합니다.
- 코드를 수정할 일이 생기면 GitHub에서 파일만 교체하면 Vercel이 자동으로 다시 배포합니다.


---

## 카톡으로 강사 배정 보내기 설정 (10분)

1. https://developers.kakao.com 접속 → 카카오 계정 로그인
2. **내 애플리케이션** → **애플리케이션 추가하기**
   - 앱 이름: `진로모아 운영보드` / 회사명: `진로모아커리어센터`
3. 만든 앱 → **앱 키** 에서 **JavaScript 키** 복사
4. **플랫폼** (또는 앱 설정 → 플랫폼) → **Web** → **사이트 도메인** 에 운영보드 주소 등록
   - 예: `https://jinromoa-board.vercel.app`
5. 운영보드 → 화면 아래 **센터 정보** → `카카오 JavaScript 키` 칸에 붙여넣기 → 저장

사용: 강의 상세 → 강사 콜시트 만들기 → **카톡으로 보내기** → 강사 대화방 선택 → 전송
강사가 카드의 **상세 보기 · 회신하기** 를 누르면 콜시트를 보고 수락/거절을 누를 수 있습니다.
수락하면 강의 상태가 자동으로 **배정** 으로 바뀝니다.
